#pragma once
#include "GameNode.h"
#include "Subject.h"

class Boss;
class CollisionCheck;

class BossManager : public GameNode
{
private:
	enum BOSS_TYPE{STAGE_ONE_BOSS, STAGE_TWO_BOSS, STAGE_THREE_BOSS, BOSS_TYPE_END};

	CollisionCheck* collisionCheck;

	vector<Boss*> vBoss;	//3����
	SceneManager* sceneManagerObserver; //�ɼ��� ��Ͼ�� ��Ű����?

	RECT bossRect;			//boss 3���� rect
	FPOINT bossPos;
	FPOINT bossPosItem[3];
	bool isBossAlive;
	bool isBoss1Alive;
	bool isBoss2Alive;
	bool isBoss3Alive;
	bool AisBoss1Alive;
	bool AisBoss2Alive;
	bool AisBoss3Alive;
	DROPENEMY dropEnemy;
	//boss 3���� rect
	Image* img;
	int currFrame;
	int maxFrame;
	int frameTime;
	int currBossNumber;
	int printNumber;

	int attackValue;

public:

	HRESULT Init();
	HRESULT Init(CollisionCheck* collisionCheck, FPOINT* playerPos);

	virtual void RegisterObserver(SceneManager* scenemanager) ;

	virtual void UnRegisterObserver() ;

	virtual void notifyObserve() ;

	//virtual DROPENEMY GetDropEnemy() { return BOSSDROP; }

	void Release();
	void Update();
	void Render(HDC hdc);

	inline bool GetIsAlive(){return isBossAlive;}
	inline void SetBossPos(FPOINT bossPos) { this->bossPos = bossPos; }
	
	bool GetEnding();
	void SetBossLife();
	inline void SetAttackValue(int attackValue) { this->attackValue = attackValue; }

	inline RECT GetBossRect() { return bossRect; }
	inline FPOINT GetBossPos() { return bossPos; }
	inline bool  GetisBoss1Alive() { return isBoss1Alive; }
	inline bool  GetisBoss2Alive() { return isBoss2Alive; }
	inline bool  GetisBoss3Alive() { return isBoss3Alive; }
	inline bool  GetAisBoss1Alive() { return AisBoss1Alive; }
	inline bool  GetAisBoss2Alive() { return AisBoss2Alive; }
	inline bool  GetAisBoss3Alive() { return AisBoss3Alive; }
	inline FPOINT GetBoss1Pos() {return bossPosItem[0];}
	inline FPOINT GetBoss2Pos() { return bossPosItem[1]; }
	inline FPOINT GetBoss3Pos() { return bossPosItem[2]; }

	
};

