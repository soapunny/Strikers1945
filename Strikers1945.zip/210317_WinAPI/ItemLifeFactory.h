#pragma once
#include "ItemFactory.h"

class ItemLifeFactory : public ItemFactory
{
public:
	virtual Item* CreatItem();
};

