#include "NotSkill.h"
#include "Missile.h"
void NotSkill::UseSkill(Missile* missile, FPOINT* lpTargetPos)
{

}